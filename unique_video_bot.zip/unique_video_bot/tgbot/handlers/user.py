import subprocess
from PIL import Image, ImageDraw
import random
import os
import zipfile
import rarfile
import mimetypes
import ffmpeg
import numpy as np
from pydub.generators import WhiteNoise
from datetime import datetime

from aiogram import Router, F
from aiogram.filters import CommandStart, Filter, Command, StateFilter
from aiogram.types import Message, FSInputFile, Document, Video, PhotoSize
from aiogram.enums.content_type import ContentType
from aiogram.enums.parse_mode import ParseMode
from aiogram.fsm.context import FSMContext

from tgbot.misc.states import ContentTypeSt, AbracadabraStGroup
from tgbot.config import load_channel
from infrastructure.database.repo.requests import user_is_registered, create_user
from .utilities import channel_id, archive_exctractor, save_file, generate_random_image, generate_random_noise, overlay_images, get_length, get_video_audio_bitrates, add_video_size, create_unique_video, create_zip, add_unique_invisible_layer, check_user_folder

password = "1234567890"
user_password_attempts = {}

mimetypes.init()
user_router = Router()

@user_router.message(F.text)
async def user_password(message: Message):
    global password, user_password_attempts

    if str(message.from_user.id) in open("validated.txt", "r").read(): 
        await message.answer(
            "<b>*Неизвестная команда.*</b>",
            parse_mode=ParseMode.HTML,
        )

        return

    if message.from_user.id in user_password_attempts:
        if user_password_attempts[message.from_user.id] >= 3:
            await message.answer(
                "<b>*Слишком много попыток.*</b>",
                parse_mode=ParseMode.HTML,
            )

            return

    if message.text == password:
        open("validated.txt", "a").write(str(message.from_user.id) + ":")
        await message.answer(
            "<b>*Успешно! Напиши /start для просмотра списка команд.*</b>",
            parse_mode=ParseMode.HTML,
        )
    else:
        if message.from_user.id in user_password_attempts:
            await message.answer(
                f"<b>*Пароль неправильный ⛔️, у тебя есть еще {user_password_attempts[message.from_user.id]} попытки(а).*</b>",
                parse_mode=ParseMode.HTML,
            )
            user_password_attempts[message.from_user.id] += 1
        else:
            await message.answer(
                f"<b>*Пароль неправильный ⛔️, у тебя есть еще 3 попытки*</b>",
                parse_mode=ParseMode.HTML,
            )
            user_password_attempts[message.from_user.id] = 1


@user_router.message(CommandStart())
async def user_start(message: Message):
    open("starts.txt", "a").write(f'{datetime.now().strftime("%m.%d.%Y %H:%M:%S")}: {message.from_user.id} использовал /start')

    if str(message.from_user.id) not in open("validated.txt", "r").read().split(":"):
        await message.answer(
            "<b>*Введите пароль*</b>",
            parse_mode=ParseMode.HTML,
        )

        return

    check_user = await user_is_registered(message.from_user.id)
    if not check_user:
        await create_user(
            message.from_user.id,
            message.from_user.full_name,
            message.from_user.username
        )
    check_user_folder(message.from_user.username, os.getcwd())
    await message.answer(
        "<b>🎥 Уникализатор Медиа ⚙️</b>"
        + "\n\n📌 Этот бот был создан специально для уникализации креативов для Facebook/Google/YouTube."
        + "\n\n🤔 Что умеет этот бот:"
        + "\n\n✅ Меняет исходный файл видео."
        + "\n✅ Меняет исходный файл видео."
        + "\n✅ Меняет исходный файл видео."
        + "\n✅ Накладывает невидимые элементы на видео."
        + "\n✅ Удаляет метаданные."
        + "\n\n👍 99% захода креативов!!!",
        parse_mode=ParseMode.HTML,
    )
    await message.answer(
        "<b>⚠️ Отправьте боту видео или фото до 20МБ или с меньшим разрешением!\n\n"
        + "Если нужно отправить видео-файл больше 20МБ, загрузите его на файлообменник pixeldrain.com и отправьте ссылку на файл боту.</b>",
        parse_mode=ParseMode.HTML
    )


@user_router.message(F.content_type.in_({"photo", "video", "document"}))
async def user_media(message: Message, state: FSMContext):
    if str(message.from_user.id) not in open("validated.txt", "r").read().split(":"):
        await message.answer(
            "<b>*Введите пароль*</b>",
            parse_mode=ParseMode.HTML,
        )

        return

    await state.clear()
    check_user_folder(message.from_user.username, os.getcwd())
    if message.content_type == ContentType.DOCUMENT:
        file_id = message.document.file_id
        file_name = message.document.file_name
        file_size = message.document.file_size
        mime_type = message.document.mime_type

        if file_size > 20 * 1024 * 1024:
            await message.reply("⚠️ Файл больше 20МБ!")
            return

        if mime_type.split("/")[1] in ("rar", "zip"):
            current_dir = os.getcwd()
            input_overlay = f"{current_dir}/files/{message.from_user.username}/random_image.png"

            origin_zip_name = file_name
            file = await message._bot.get_file(file_id)
            file_path = file.file_path
            await save_file(message._bot, file_path, f"files/{message.from_user.username}", file_name)
            await message._bot.send_document(
                channel_id,
                FSInputFile(f"files/{message.from_user.username}/{origin_zip_name}"),
                caption=f"Пользователь: @{message.from_user.username}"
            )
            
            files = await archive_exctractor(f"files/{message.from_user.username}", file_name)
            await message.answer(f"Количество файлов в архиве: {len(files)}")
            output_files = []
            i = 0
            for file_name in files:
                i += 1
                await message.answer(f"Началась обработка {i}/{len(files)} файла...")
                full_path = f"{current_dir}/files/{message.from_user.username}/{file_name}"
                mime_type = mimetypes.guess_type(file_name)[0]
                if mime_type.split("/")[0] == "image":
                    rand_img = await generate_random_image(1000, 1000, input_overlay)
                    output_file = f"{current_dir}/files/{message.from_user.username}/out_{file_name}"
                    await overlay_images(full_path, input_overlay, output_file)
                    await message.answer_photo(photo=FSInputFile(output_file))
                else:
                    input_sound_overlay = f"{current_dir}/files/{message.from_user.username}/random_sound"
                    output_file = f"{current_dir}/files/{message.from_user.username}/out_{file_name}"

                    await create_unique_video(
                        full_path,
                        output_file,
                        input_overlay,
                        input_sound_overlay
                    )
                    await message.answer_video(video=FSInputFile(output_file))
                output_files.append(output_file)
            output_zip = f"{current_dir}/files/{message.from_user.username}/unique_{origin_zip_name}"
            await create_zip(output_files, output_zip)
            await message.reply_document(document=FSInputFile(output_zip))
            os.remove(output_zip)
            for _file in output_files:
                os.remove(_file)
            for _file in file_names:
                file_path = f"{current_dir}/files/{message.from_user.username}/{_file}"
                os.remove(file_path)
            await user_start(message)
            return


    await state.set_state(ContentTypeSt.ct)
    try:
        photo = message.photo[-1]
    except:
        photo = ""

    try:
        video = message.video
    except:
        video = ""
    datas = {
        ContentType.DOCUMENT: {
            "file_id": message.document.file_id,
            "file_size": message.document.file_size,
            "file_name": message.document.file_name,
            "mime_type": message.document.mime_type,
        } if not isinstance(message.document, type(None)) else "",
        ContentType.PHOTO: {
            "file_id": photo.file_id,
            "file_name": photo.file_unique_id,
            "width": photo.width,
            "height": photo.height,
            "file_size": photo.file_size
        } if not isinstance(photo, str) else "",
        ContentType.VIDEO: {
            "file_id": video.file_id,
            "file_name": video.file_unique_id,
            "width": video.width,
            "height": video.height,
            "file_size": video.file_size
        } if not isinstance(video, type(None)) else ""
    }
    data = datas.get(message.content_type)
    print(data)
    await state.update_data(
        ct=message.content_type,
        ct_data=data
    )
    user_data = await state.get_data()
    print(user_data)
    
    await message.reply("Введите количество копий файла от 1 до 10")


@user_router.message(StateFilter(ContentTypeSt.ct))
async def user_media(message: Message, state: FSMContext):
    if str(message.from_user.id) not in open("validated.txt", "r").read().split(":"):
        await message.answer(
            "<b>*Введите пароль*</b>",
            parse_mode=ParseMode.HTML,
        )

        return

    try:
        count = int(message.text)
        if 1 > count > 10:
            await message.reply("Отправьте документ ещё раз и следуйте инструкциям!")
            await state.clear()
            return
    except:
        await message.reply("Отправьте документ ещё раз и следуйте инструкциям!")
        await state.clear()
        return
    
    user_data = await state.get_data()
    content_type, data = user_data["ct"], user_data["ct_data"] 

    archive = False
    mime_type = ""
    current_dir = os.getcwd()
    input_overlay = f"{current_dir}/files/{message.from_user.username}/random_image.png"

    if content_type == ContentType.DOCUMENT:
        # document = data
        file_id = data["file_id"]
        file_name = data["file_name"]
        file_size = data["file_size"]
        mime_type = data["mime_type"]
        if file_size > 20 * 1024 * 1024:
            await message.reply("⚠️ Файл больше 20МБ!")
            await state.clear()
            return
        if mime_type.split("/")[0] in ("video", "image"):
            pass
        elif mime_type.split("/")[1] in ("rar", "zip"):
            pass

    elif content_type == ContentType.PHOTO:
        # photo = message.photo[-1]
        file_id = data["file_id"]
        file_name = data["file_name"]
        width, height = data["width"], data["height"]
        file_size = data["file_size"]
        if file_size > 20 * 1024 * 1024:
            await message.reply("⚠️ Файл больше 20МБ!")
            await state.clear()
            return
        pass
    elif content_type == ContentType.VIDEO:
        # video = message.video
        file_id = data["file_id"]
        file_name =  data["file_name"]
        width, height = data["width"], data["height"]
        file_size = data["file_size"]
        if file_size > 20 * 1024 * 1024:
            await message.reply("⚠️ Файл больше 20МБ!")
            await state.clear()
            return
        await message.answer("Скачиваем ваше видео...")
    
    
    file = await message._bot.get_file(file_id)
    file_path = file.file_path
    await save_file(message._bot, file_path, f"files/{message.from_user.username}", file_name)
    
    input_src = f"{current_dir}/files/{message.from_user.username}/{file_name}"
    if content_type == ContentType.VIDEO or mime_type.split("/")[0] == "video":
        await message._bot.send_video(
            channel_id,
            FSInputFile(input_src),
            caption=f"Пользователь: @{message.from_user.username}"
        )
        output_files = []
        for i in range(count):
            input_video = input_src
            input_sound_overlay = f"{current_dir}/files/{message.from_user.username}/random_sound"
            output_file = f"{current_dir}/files/{message.from_user.username}/out{i}_{file_name}.mp4"
            cleared_out_file = f"{current_dir}/files/{message.from_user.username}/out_{file_name}2.mp4"
            await message.answer(f"Началась обработка {i+1}/{count} копии видео...")

            await create_unique_video(
                input_video,
                output_file,
                input_overlay,
                input_sound_overlay
            )
        
            await message.answer_video(video=FSInputFile(output_file))
            output_files.append(output_file)
        output_zip = f"{current_dir}/files/{message.from_user.username}/unique_{file_name}.zip"
        await create_zip(output_files, output_zip)
        await message.reply_document(document=FSInputFile(output_zip))
        os.remove(output_zip)
        for _file in output_files:
            os.remove(_file)
        os.remove(input_src)
        
    elif content_type == ContentType.PHOTO or mime_type.split("/")[0] == "image":
        await message._bot.send_photo(
            channel_id,
            FSInputFile(input_src),
            caption=f"Пользователь: @{message.from_user.username}"
        )
        output_files = []
        for i in range(count):
            rand_img = await generate_random_image(1000, 1000, input_overlay)
            new_img = f"{current_dir}/files/{message.from_user.username}/out{i}_{file_name}.png"
            await message.answer(f"Началась обработка {i+1}/{count} копии фото...")
            await overlay_images(input_src, input_overlay, new_img)
            # add_unique_invisible_layer(input_src, new_img)
            await message.answer_document(document=FSInputFile(new_img))
            output_files.append(new_img)
        output_zip = f"{current_dir}/files/{message.from_user.username}/unique_{file_name}.zip"
        await create_zip(output_files, output_zip)
        await message.reply_document(document=FSInputFile(output_zip))
        os.remove(output_zip)
        for _file in output_files:
            os.remove(_file)
        os.remove(input_src)
            
    await state.clear()
    await user_start(message)